---
name: adaptlypost
description: Manage connected social accounts, drafts, schedules, and post analytics through the connected AdaptlyPost MCP.
---

# adaptlypost

Use server `adaptlypost` / `/root/scripts/mcp-adaptlypost`; inspect its live schema because existing native launchers are preserved. The verified CLI connects to official `https://mcp.adaptlypost.com/mcp` with Bearer `ADAPTLYPOST_API_KEY` from Doppler: `/root/scripts/content-service adaptlypost --call TOOL < payload.json`. The tool names below refer to this official CLI route; the native REST adapter may use names such as `list_social_accounts`. REST base: `https://post.adaptlypost.com/post/api/v1`.

- `list_workspaces` → `list_accounts`; retain the chosen workspace ID for every related call and resolve exact account IDs. REST `GET /me` reports effective key permissions.
- Discover current create/update/analytics tool schemas. For REST drafts explicitly set `saveAsDraft:true`: omitting `scheduledAt` on a create request can publish immediately.
- Publishing and scheduling use the current user request's scope, destination, and timezone. Do not duplicate a post through another scheduler.
- Record post IDs and inspect results before retrying after timeouts. Do not change workspace membership, tokens, or webhooks unless the task requires it.
- Model-backed caption/image helpers need established subscription coverage before use; approved subscription CLIs can create text instead.

[API docs](https://adaptlypost.com/docs/introduction) · [Identity/permissions](https://adaptlypost.com/docs/api-me) · [MCP](https://adaptlypost.com/features/agents) · [Requested skill listing](https://clawhub.ai/tarasshyn/adaptlypost)
