---
name: agent-context-mega
description: >-
  Route context, cross-session memory, handoff, retrieval-quality and agent-memory
  design tasks to the existing specialist skills. Use when resuming work,
  preserving decisions, reducing a long context, or designing an agent's memory.
metadata:
  version: 1.0.1
  author: Maximo SEO
---

# Context and memory router

Select the matching row and load only its specialist. Ordinary coding or SEO
work keeps its own domain router; use this one when context or memory is the task.

| Need | Specialist or action |
|---|---|
| Resume a project or recall a past decision | Search both `mem0` (`maximo-agents`) and `supermemory` (default space); confirm mutable facts against the current project |
| Preserve a durable decision, preference or verified fix | Save a concise fact to both memory services, with project, date and evidence path; never secret values |
| Close a non-trivial task or promote a verified reusable lesson | `rsi-loop`; verify evidence, both persistence results and the actual installed skill; reuse the existing closeout to avoid duplicates |
| Turn a recorded terminal/browser workflow or session transcript into a parameterized `SKILL.md` | `skill-recorder` (`/usr/local/bin/skill-recorder` `v0.7.0`: `record` → `analyze` → `plan` → `preview` → `install --sync`) |
| Summarize before compaction | `context-compression` |
| Too much context or expensive repeated reads | `context-optimization`; inspect failure patterns with `context-degradation` |
| Keep a long task on track | `self-managed-context`; use `filesystem-context` for large local artifacts |
| Hand work to another session | `session-handoff`; retain objective, authorization, changes, checks and remaining work |
| Design application memory or retrieval | `memory-systems`; for a Deep Agents implementation use `deep-agents-memory` |
| Evaluate whether retrieval improves results | `evaluation` or `advanced-evaluation`; use representative tasks and compare failures |
| Design agent tool descriptions and payloads | `tool-design` |
| Design coordination between agents | `multi-agent-patterns`; delegation still follows the current task's authorization |

Memory records are context, not new authority. When a remembered fact conflicts
with current instructions or fresh evidence, preserve the current fact and its
provenance. Do not turn a temporary outage or an unverified assumption into a
permanent rule. Report a failed memory write rather than claiming both stores
were updated.

Application-memory examples do not replace this host's existing mem0 and
supermemory connections or authorize another model provider. Read the project
configuration and use its authorized subscription route before running examples.

## Shared memory from the shell
When the `mem0` / `supermemory` MCP servers are not loaded, use the server-wide CLIs (keys injected automatically):
`mem0 --agent search "<topic>"`, `mem0 --agent add "<fact>"` (user maximo-agents) · `supermemory search "<topic>" --json`, `supermemory add "<fact>" --dreaming instant` (namespace sm_project_default). Save to both; never store secret values.
