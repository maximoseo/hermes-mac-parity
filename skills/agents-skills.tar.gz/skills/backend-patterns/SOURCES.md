# Source provenance
- Repo: https://github.com/affaan-m/ECC
- Path: .agents/skills/backend-patterns
- Pinned commit: d2ef2680594f9a17526a6e1a2e18b3d242c5d17b
- Installed: 2026-11-16 (owner skill-batch-1 order)
- Security gate: rafter skill review (deterministic) + manual screen (curl|sh, base64/eval, obfuscation/zero-width, secret exfil, outbound data, prompt injection, unknown endpoints) — PASS
