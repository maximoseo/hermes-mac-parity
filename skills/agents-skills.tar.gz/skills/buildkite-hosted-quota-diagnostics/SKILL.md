---
name: buildkite-hosted-quota-diagnostics
description: Diagnose Buildkite jobs canceled before starting when REST lacks a reason; preserve mandatory CI and isolated verification evidence.
version: 1.0.0
---

# Buildkite pre-start cancellation

Use when an authorized CI run fails before any command starts and REST returns null exit status/reason. Do not infer a code defect or a billing problem from those fields alone.

1. Read the exact build and job IDs, queue, commit and start timestamps. Retain sanitized evidence. Load the existing Buildkite API credential from Doppler into process memory; never print headers or use tokens in URLs.
2. Read job events through a **named** GraphQL query. For command jobs, inspect the generic event type:

```graphql
query InspectJobCancellation {
  job(uuid: "JOB_UUID") {
    ... on JobTypeCommand {
      state
      events(first: 20) {
        edges {
          node {
            ... on JobEventGeneric { type timestamp }
          }
        }
      }
    }
  }
}
```

3. `HOSTED_MINUTES_LIMIT_REACHED` is direct evidence of hosted quota exhaustion. An existing queue that is not paused does not refute it. Preserve the event and timestamp; a missing log is not a passed test.
4. Only within an already authorized task and verified existing account capacity, consider an isolated self-hosted executor for the same CI checks. This is an execution alternative, not a waiver. Never purchase capacity, add a provider or weaken checks to make a run green.
5. Keep shared pipelines unchanged. Restrict a dedicated private pipeline to the task branch. Verify its repository, visibility and filters. Buildkite rejects API builds when the corresponding branch/PR source setting is disabled; enabling branch builds must still retain the task-only branch filter. Inspect existing builds before triggering another run.
6. Transfer a verified exact-commit checkout into the isolated environment without host credentials. Pin and checksum the agent binary, use the required runtime version and run every required command. Record each actual exit code and make any required failure fail the build. Never replace CI evidence with a fabricated status.
7. Use a short-lived agent token, retain it only in process memory, then revoke it. Stop the owned agent, terminate the sandbox even if agent-stop fails, remove the temporary queue after the agent disconnects, and archive the private pipeline to retain logs without future automatic work. Verify cleanup separately; an exception in one cleanup step must not skip the others.
8. Report the tested SHA, build URL, actual checks, failures/skips and remaining gates. A green Buildkite run does not satisfy a separately required CircleCI, native-device, production or release-popup check.

## Evidence

2026-10-26: job events identified hosted-minute exhaustion after REST supplied no cause. A private branch-limited Buildkite pipeline ran the exact candidate in E2B. Build 1 failed the real palette guard; after the defect and an affected contrast assertion were fixed, build 3 passed all nine standard-CI stages and 3,227 tests. Temporary agents, tokens and queues were removed and the pipeline archived. CircleCI and native-device gates remained explicitly blocked; no production completion was claimed.

Local sanitized record: `/root/task-artifacts/central-brain-20261026/buildkite-isolated-report.json`.

Primary references: [Build API](https://buildkite.com/docs/apis/rest-api/builds), [queue API](https://buildkite.com/docs/apis/rest-api/clusters/queues), [agent token API](https://buildkite.com/docs/apis/rest-api/clusters/agent-tokens), [pipeline archive API](https://buildkite.com/docs/apis/rest-api/pipelines#archive-a-pipeline). Recheck current account capacity and API behavior when using this procedure.
