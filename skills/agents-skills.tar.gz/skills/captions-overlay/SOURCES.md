# Source
- Repository: https://github.com/heygen-com/hyperframes
- Pinned commit: d5f0b1a5bfd498256c1642f32451e670616e831b
- Installed by: Hermes skill-batch-3 install (owner order 2026-11-15)
- Security review: `rafter skill review` clean (0 findings) + manual screen (no curl|sh, no base64/eval/exec payloads, no obfuscation, no secret exfiltration, no prompt-injection text; zero-width scan clean — only UTF-8 BOMs)
