# Source

- Repository: https://github.com/emilkowalski/skills
- Pinned commit: 64eb3deb9a5fbfa041faf783e0bc3fd635872e9c
- Installed: 2026-11-16 (batch 2 skill install, owner order 2026-11-15)
- Security: rafter skill review + manual screen (curl|sh, base64/eval/exec, obfuscation/zero-width, secret exfil, outbound data URLs, prompt-injection) — CLEAN (rafter 0 findings); manual screen clean
