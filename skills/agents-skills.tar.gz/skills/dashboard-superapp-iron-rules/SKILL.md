---
name: dashboard-superapp-iron-rules
description: Use when building or merging dashboards in the panel.
version: 1.0.0
author: Hermes Agent (owner rules)
license: MIT
platforms: [linux]
hermes: null
tags:
- dashboards-panel
- superapp
- iron-rule
- design
- architecture
metadata:
  hermes:
    tags:
    - dashboards-panel
    - superapp
    - iron-rule
    - design
    - architecture
---

# Dashboards-Panel SUPER APP — Iron Rules (owner, 2026-10-19)

The dashboards panel (https://dashboards-panel.maximo-seo.ai/, repo `maximoseo/dashboards-panel`) is a **SUPER APP**: every dashboard is an **integral part of the panel's own codebase and its GitHub repo**.

## The rules (violations block the release)

1. **No iframes, ever.** A dashboard must never be embedded via `<iframe>`, external embed, or a wrapper that renders a separately-hosted/native dashboard inside the panel. Every surface renders from the repo's own React components.
2. **No "native dashboard" shortcuts.** Do not link out to, proxy, or mirror a dashboard's standalone site instead of implementing it in the panel. If a dashboard exists as its own app elsewhere, port its UI into the panel code.
3. **Merged dashboards keep their original design.** When dashboards are consolidated under one parent with tabs/sub-tabs (e.g. Fleet Tracker under Agents), each one MUST preserve its original design identity — layout language, color system, density, interaction patterns. Consolidation restructures navigation only, never the visual identity.
   **Restoring/keeping an original design (procedure):** the source of truth is the app's OWN repo CSS — `globals.css` / `tokens.css` / `tailwind.config.ts` under `maximoseo/<app>` (fetch with `gh api repos/maximoseo/<app>/contents/<path> -q .content | base64 -d`; try `main` then the repo's actual default branch). Extract that app's palette/typography tokens and map them onto the shared token layer (`.os-theme-<code>` in `original-shell.css`, registered in `appThemes.ts` for the generic renderer or `SEO_MODULE_THEMES` for the SEO-family faces) so the renderer root carries the app's identity. NEVER invent or hand-pick a palette — if the app has no discoverable CSS source, say so and leave the theme unclaimed rather than guessing colors.
4. **First-class integration.** Each dashboard lives in the panel's routing/workspace modes, state, auth and data layers — as components in the repo, buildable from `main`, reviewable in PRs.
5. **Verification gate (run on every change):** `grep -riE "<iframe|embed|external.*window" src/` must be clean; each tabbed dashboard must be reachable as a route/mode and render from repo components; visual identity spot-check against the dashboard's original design. **Design-quality audit across surfaces:** loop every workspace mode at 1440/768/390 and check horizontal overflow, touch-target sizes and text sizes; measurable floors are: interactive targets ≥32px tall (≥40px for primary actions) and no label text below 11px. Fix violations at the **design-system level** (token/media-query floors in `mobile-ux.css`/`design-system.css`) before touching individual components — one floor rule clears hundreds of instances at once and new components inherit it. Deep links under test need `?mode=<workspace>&app=<id>`; a bare `?app=` silently falls back to overview and the surface under test never renders. **Architecture-invariant tests are source-string tests** — the suite greps App.tsx for the old shape (an embed component name, a branch pattern), so when the invariant itself changes (e.g. going iframe-free) those tests fail BY DESIGN: grep the test tree for the removed SYMBOL, rewrite each assertion to enforce the NEW invariant (e.g. "src contains no <iframe"), and keep the tests — they are what stops the violation from regressing.

## Multi-agent harmony (owner, added 2026-10-19)

6. **One agent per repo at a time.** Before touching the panel: `agent-lock status dashboards-panel` (or check branches/dirty worktree/PRs). If another agent has in-flight work — never edit their checkout or branch; use your own worktree + branch and merge via PR. Never force-push over anyone's work.
7. **Serialize destructive steps.** Builds, `git clean`, dependency installs, migrations and deploys are serialized — one agent at a time. Parallel work is fine for READ-ONLY inspection and for edits on separate branches.
8. **Leave the tree buildable after every step.** A multi-agent sequence must not break `main` between steps: commit or stash before handing over; never leave half-resolved conflicts; write what you touched (branch names, files) where the next agent can see it.
9. **Rebase/merge before shipping**, not during someone else's session; resolve conflicts fully (no `<<<<<<<` leftovers — the CI grep blocks them). After your own PR is squash-merged, do NOT re-push the same branch for follow-up work — the base now holds a squashed copy of your commits and the push conflicts or reports "no commits between"; branch fresh from the updated base and cherry-pick the new commits instead.
10. **Review budget exhaustion never blocks delivery.** If any reviewer (CodeRabbit, cubic, Kilo, or any app-posted review) runs out of budget/quota — log `SKIPPED: budget exhausted` in the review evidence and CONTINUE the task to completion. The gate requires the review ATTEMPT + the other reviewers; a paid-reviewer quota outage is never a reason to stop, stall, or leave work unfinished. Same for any single reviewer being down.
11. **Every LIVE production change is logged + announced in the popup (owner, 2026-10-20; extended 2026-10-29 & 2026-10-30).** Any agent whose change to https://dashboards-panel.maximo-seo.ai/ reaches the LIVE PRODUCTION URL must ship, in the same release: (a) a release log entry (the `changelog` entry in `public/app-manifest.json` with the version bump + `verification` block + `agent: { id, nick, server }`), and (b) a What's-new popup entry that shows **the new update version number, WHICH AGENT/BOT shipped it, WHICH SERVER (`Server 735` / `Server 935` or `srv735` / `srv935`), at WHAT TIME, WHAT was done (English `notes`, Hebrew `notes_he`), and a working close button** (`✕` / `Later`) that dismisses the popup once seen. Set `CHANGELOG_AGENT_ID`, `CHANGELOG_AGENT_NICK`, and `CHANGELOG_AGENT_SERVER=srv735|srv935` (or `CHANGELOG_SERVER=735|935`). The popup window renders **the release TIME automatically** from `verification.checkedAt` — so a correct `checkedAt` is mandatory. No popup entry = the change is NOT done. Schema details in `dashboard-release-gate`.

Related: `dashboard-release-gate` (deployment + What's-new popup), `code-review-stack` (gate order), owner iron rules (platform design reviews, real-data tests).
