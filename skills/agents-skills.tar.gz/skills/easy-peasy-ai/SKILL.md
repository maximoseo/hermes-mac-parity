---
name: easy-peasy-ai
description: "Generate text, images, videos, speech, and transcriptions with Easy-Peasy.AI via its MCP server (13 tools). Use this skill whenever the task needs AI-generated content or media: marketing/ad copy, long-form articles, image generation or editing (product shots, illustrations, social creatives), short video generation, text-to-speech with a specific voice, or audio/video transcription. Also trigger when the user says \"generate an image/video/voiceover\", \"transcribe this audio\", \"write copy using a template\", or names Easy-Pasy AI / marky. The skill covers the async media flow (generate → poll → display), the writing-template workflow, and voice selection."
metadata:
  version: 1.0.0
  author: Maximo SEO
---

# Easy-Peasy.AI Skill

## Purpose

Drive the Easy-Peasy.AI MCP server for all generative content work: text, images, video, speech, and transcription. The server is registered as the `easy-peasy` MCP server in every agent CLI; the API key lives in Doppler (`agent-apis/prd`, `EASY_PEASY_API_KEY`) and is injected at runtime via `/root/scripts/dmcp` — never hardcode or echo it.

- **MCP endpoint**: `https://easy-peasy.ai/mcp` (`x-api-key` header)
- **Local wiring**: `/root/scripts/mcp-easypeasy` (dmcp + mcp-remote), registered as `easy-peasy` in every agent CLI
- **Tool prefix in sessions**: `easy_peasy__*` / `easy-peasy__*`

## Tool Map (13 tools)

| Tool | Use for |
|------|---------|
| `get_account` | Verify connectivity only when explicitly asked |
| `list_templates` / `get_template` | Discover/inspect writing templates (presets) |
| `generate_text` | Run a template or a free-form prompt |
| `generate_image` | Create or edit an image |
| `get_image` | Poll for a finished image |
| `generate_video` / `get_video` | Create/poll a video |
| `display_media` | Render a finished image/video to the user |
| `list_voices` / `generate_speech` | Pick a voice, render TTS audio |
| `transcribe_audio` / `get_transcription` | Transcribe audio, fetch the result |

## Core Workflows

### 1. Template-based text (highest quality path)
```
list_templates(category?) → get_template(slug) → generate_text(template/prompt, variables)
```
Templates encode proven prompt structure — prefer them over raw prompts for ads, product descriptions, and emails.

### 2. Async media (image/video/speech/transcription)
Generation is asynchronous: the generate call returns a job/id, and you poll the matching `get_*` tool until the result is ready. Then `display_media` for images/videos so the user sees the output inline. Do not re-call `generate_*` while a job is in flight — poll instead.

### 3. Speech
`list_voices` first when the user cares about the voice (language/gender/style); otherwise use the default. Output audio is returned as a URL — hand it to the user or attach it to the deliverable.

## REST API Endpoints (Direct HTTP via `dmcp`)

When calling the REST API from scripts or automation (with `x-api-key: $EASY_PEASY_API_KEY` injected via `/root/scripts/dmcp`):

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `https://easy-peasy.ai/api/presets` | `GET` | List writing templates/presets (`?limit=50&offset=0&category=...`) |
| `https://easy-peasy.ai/api/presets/{slug}` | `GET` | Inspect required fields (`keywords`, `extra1`..`extra14`) for a preset |
| `https://easy-peasy.ai/api/generate` | `POST` | Generate text from a preset (`{"preset":"...","keywords":"...","tone":"...","language":"..."}`) |
| `https://easy-peasy.ai/api/generate-image` | `POST` | Generate (`model`: `Nano Banana 2`, `FLUX.2 [max]`, `Seedream 5.0 Pro`) or edit (`editModel` + `image`/`images`) images |
| `https://easy-peasy.ai/api/generate-video` | `POST` | Start async video (`model`: `MiniMax H3 Max`, `Veo 3.1`, `Veo 3.1 Fast`, `Seedance 2.5`; poll `GET /api/videos/{id}`) |
| `https://easy-peasy.ai/api/audios` | `POST` | Start async audio/video transcription (`url`, `language`, `detect_speakers`; poll `GET /api/audios/{uuid}`) |
| `https://easy-peasy.ai/api/tts/voices` & `/api/tts/generate` | `GET`/`POST` | List voices & generate TTS audio (`text`, `voice_id`, `speed`, `output_format`) |
| `https://easy-peasy.ai/api/sound/generate` | `POST` | Generate sound effects synchronously from a text description |
| `https://easy-peasy.ai/api/chat/completions` | `POST` | OpenAI-compatible Chat Completions (`baseURL: https://easy-peasy.ai/api`, `model: gemini-3-flash` etc.) |
| `https://bots.easy-peasy.ai/bot/{id}/api` | `POST` | Chat with a custom Easy-Peasy.AI Bot / Agent |

## Rules

- Never print the API key; it is in Doppler (`EASY_PEASY_API_KEY` / `EASYPEASY_API_KEY` in `agent-apis/prd` and `agents/prd`) and injected by `dmcp`.
- Prefer templates over free-form prompts for repeatable content types.
- For long generations, pass generous timeouts and poll; treat "still processing" as normal, not an error.
- This service is an explicit owner-approved addition (key provided 2026-10-15); it sits alongside — not inside — the subscription-only LLM rule for dashboard inference.

## Position in the Workflow

```
content brief / creative request → [THIS SKILL] → finished copy, images, video, voiceover, or transcript
```

<!-- content-services-routing:start -->

## Connected content services

For downstream media rendering, social distribution/analytics, or originality checks, route to [content-ops-mega](/root/.agents/skills/content-ops-mega/SKILL.md). It selects HTML/CSS to Image, Creatomate, Metricool, Postiz, AdaptlyPost, Copyscape, or Originality.ai according to the deliverable. Preserve this skill's existing generation/research workflow; invoke only the additional capability the task needs. The canonical service skill and live schema take precedence over historical tool names/counts in this document. Model-backed tools require verified subscription coverage; service credentials alone do not establish it.

<!-- content-services-routing:end -->
