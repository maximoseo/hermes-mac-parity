# Source provenance
- Repo: https://github.com/OpenOSINT/OpenOSINT
- Path: skills/exposure
- Pinned commit: c08848ef9b5bd657632bc8d82103745526843db9
- Installed: 2026-11-16 (owner skill-batch-1 order)
- Security gate: rafter skill review (deterministic) + manual screen (curl|sh, base64/eval, obfuscation/zero-width, secret exfil, outbound data, prompt injection, unknown endpoints) — PASS
