# Sources

- Repo: https://github.com/patchy631/ai-engineering-hub
- Pinned commit: 042aeb5067384981eeba6a07fa882f436bb1660d
- Installed: 2026-11-16 (batch 0 skill install, owner order 2026-11-15)
- Security review: rafter skill review (deterministic pass) + manual screen (malware patterns, injection, obfuscation, exfil hosts, zero-width chars) — clean for this skill dir.
