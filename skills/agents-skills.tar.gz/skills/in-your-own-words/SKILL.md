---
name: in-your-own-words
description: "Restate in your own words what you think the user's goals are and what problem they're trying to solve. Use for /in-your-own-words."
disable-model-invocation: true
---
<!-- source: github.com/backnotprop/pstack (skills/in-your-own-words), MIT License (c) 2026 Lauren Tan -->


Restate in your own words what you think the user's goals are and what problem they're trying to solve.
