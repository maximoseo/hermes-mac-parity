---
name: mega-agentic-code
description: "Mega-skill from the Obsidian vault for AI-driven software engineering: agent architectures (ReAct, plan-and-execute, reflexion, multi-agent), planning & task breakdown, TDD, incremental implementation, debugging & error recovery, code review, security hardening, API design, CI/CD, git workflow, MCP tool composition, prompt engineering, structured outputs, RAG, agent testing, bootstrapping new agents and infra connections. Use for any coding, agent-building or debugging task (פיתוח, קוד, באג, סוכן, אוטומציה של קוד)."
---

# mega-agentic-code (live from the Obsidian vault)

This hub is generated from `MEGA_SKILLS/AGENTIC_CODE` in the vault. The notes below are the live source; read the ones relevant to the task with the Read tool before acting, and follow them unless the user says otherwise.

## Vault notes

- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/01_Agent_Architectures_Overview.md` — Agent Architecture מגדירה כיצד AI agent מתנהג, מחליט, ופועל.
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/02_Test_Driven_Development.md` — Write a failing test before writing the code that makes it pass. For bug fixes, reproduce the bug with a test before attempting a fix. Tests
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/03_Code_Simplification.md` — Inspired by the [Claude Code Simplifier plugin](https://github.com/anthropics/claude-plugins-official/blob/main/plugins/code-simplifier/agen
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/04_Planning_Task_Breakdown.md` — Decompose work into small, verifiable tasks with explicit acceptance criteria. Good task breakdown is the difference between an agent that c
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/05_Debugging_Error_Recovery.md` — Systematic debugging with structured triage. When something breaks, stop adding features, preserve evidence, and follow a structured process
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/06_Incremental_Implementation.md` — Build in thin vertical slices — implement one piece, test it, verify it, then expand. Avoid implementing an entire feature in one pass. Each
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/07_Code_Review_Quality.md` — Multi-dimensional code review with quality gates. Every change gets reviewed before merge — no exceptions. Review covers five axes: correctn
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/08_Performance_Optimization.md` — Measure before optimizing. Performance work without measurement is guessing — and guessing leads to premature optimization that adds complex
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/09_Security_Hardening.md` — Security-first development practices for web applications. Treat every external input as hostile, every secret as sacred, and every authoriz
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/10_CICD_Automation.md` — Automate quality gates so that no change reaches production without passing tests, lint, type checking, and build. CI/CD is the enforcement 
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/11_API_Interface_Design.md` — Design stable, well-documented interfaces that are hard to misuse. Good interfaces make the right thing easy and the wrong thing hard. This 
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/12_Frontend_UI_Engineering.md` — Build production-quality user interfaces that are accessible, performant, and visually polished. The goal is UI that looks like it was built
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/13_Git_Workflow_Versioning.md` — Git is your safety net. Treat commits as save points, branches as sandboxes, and history as documentation. With AI agents generating code at
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/14_Shipping_Launch.md` — Ship with confidence. The goal is not just to deploy — it's to deploy safely, with monitoring in place, a rollback plan ready, and a clear u
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/15_Browser_Testing_DevTools.md` — Use Chrome DevTools MCP to give your agent eyes into the browser. This bridges the gap between static code analysis and live browser executi
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/20_NanoBot_Agent_Knowledge_Integration.md` — סיכום: nanobot טוען אוטומטית את הידע של ה-Vault כל סשן, ומנווט ל-MEGA_SKILLS לפי סוג המשימה.
- `/root/vaults/HTML-REDESIGN/MEGA_SKILLS/AGENTIC_CODE/21_New_Agent_Bootstrap_Infra_Connections.md` — תרשום לי פרומט כללי לאייגנטים חדשים באנגלית ב-MD FILE FORMAT לחבר אותם ל-MCP, CLI או REST-API

_Unfilled template notes (no real content yet — rely on the library skills below instead): 02_ReAct_Pattern, 03_Plan_and_Execute, 04_Reflexion_Self_Critique, 05_Multi_Agent_Systems, 06_MCP_Server_Design, 07_MCP_Tool_Composition, 08_Context_Management, 09_Token_Budget_Tracking, 10_Memory_Systems, 11_RAG_Architectures, 12_Tool_Orchestration, 13_Error_Recovery, 14_Prompt_Engineering, 15_Chain_of_Thought, 16_Few_Shot_Learning, 17_Structured_Outputs, 18_Agent_Testing, 19_Production_Deployment_

## Related skills in the local library (read the SKILL.md when relevant)

- **flutter-dart-code-review** — Library-agnostic Flutter/Dart code review checklist covering widget best practices, state management patterns (BLoC, Riv → `/root/.claude/vault/library/flutter-dart-code-review/SKILL.md`
- **llm-trading-agent-security** — Security patterns for autonomous trading agents with wallet or transaction authority. Covers prompt injection, spend lim → `/root/.claude/vault/library/llm-trading-agent-security/SKILL.md`
- **architecture-decision-records** — Capture architectural decisions made during Claude Code sessions as structured ADRs. Auto-detects decision moments, reco → `/root/.claude/vault/library/architecture-decision-records/SKILL.md`
- **ck:code-review** — Review code quality with adversarial rigor. Supports input modes: pending changes, PR number, commit hash, codebase scan → `/root/.claude/vault/library/ck-code-review/SKILL.md`
- **code-review-and-quality** — Conducts multi-axis code review. Use before merging any change. Use when reviewing code written by yourself, another age → `/root/.claude/vault/library/code-review-and-quality/SKILL.md`
- **code-review-and-quality-ao** — Conducts multi-axis code review. Use before merging any change. Use when reviewing code written by yourself, another age → `/root/.claude/vault/library/code-review-and-quality-ao/SKILL.md`
- **debug-agent-patterns** — Evidence-based debugging skill for AI coding agents — instruments code with NDJSON logs, generates hypotheses, confirms  → `/root/.claude/vault/library/debug-agent-patterns/SKILL.md`
- **ml-kit-genai-prompt-api** — Analyzes Android codebases to implement ML Kit GenAI Prompt API. Use this skill to send natural language requests on-dev → `/root/.claude/vault/library/ml-kit-genai-prompt-api/SKILL.md`
- **n8n-extending-mcp-official** — Use when you want to expose an n8n workflow as a tool the coding agent can call. Two cases. (1) Wrap n8n API capabilitie → `/root/.claude/vault/library/n8n-extending-mcp-official/SKILL.md`
- **agent-introspection-debugging** — Structured self-debugging workflow for AI agent failures using capture, diagnosis, contained recovery, and introspection → `/root/.claude/vault/library/agent-introspection-debugging/SKILL.md`
- **ai-regression-testing** — Regression testing strategies for AI-assisted development. Sandbox-mode API testing without database dependencies, autom → `/root/.claude/vault/library/ai-regression-testing/SKILL.md`
- **api-testing** — Test API integrations by mocking responses, intercepting requests, and monitoring network traffic. Use when the user wan → `/root/.claude/vault/library/api-testing/SKILL.md`
- **github** — GitHub operations via `gh` CLI: issues, PRs, CI runs, code review, API queries. Use when: (1) checking PR status or CI,  → `/root/.claude/vault/library/github/SKILL.md`
- **mcp-server-patterns** — Build MCP servers with Node/TypeScript SDK — tools, resources, prompts, Zod validation, stdio vs Streamable HTTP. Use Co → `/root/.claude/vault/library/mcp-server-patterns/SKILL.md`
- **plankton-code-quality** — Write-time code quality enforcement using Plankton — auto-formatting, linting, and Claude-powered fixes on every file ed → `/root/.claude/vault/library/plankton-code-quality/SKILL.md`
- **principle-migrate-callers-then-delete-legacy-apis** — Apply when introducing a new internal API while old callers still exist. Migrate callers and delete the old API in the s → `/root/.claude/vault/library/principle-migrate-callers-then-delete-legacy-apis/SKILL.md`
- **principle-test-behavior-not-implementation** — Apply when you write, change, or keep a test. Assert what the code's users can observe, so that the test fails when that → `/root/.claude/vault/library/principle-test-behavior-not-implementation/SKILL.md`
- **security-review** — Use this skill when adding authentication, handling user input, working with secrets, creating API endpoints, or impleme → `/root/.claude/vault/library/security-review/SKILL.md`
- **using-n8n-mcp-skills** — Use when building, editing, validating, testing, or debugging an n8n workflow through the n8n-mcp MCP server — designing → `/root/.claude/vault/library/using-n8n-mcp-skills/SKILL.md`
- **coding-agent** — Delegate coding tasks to Codex, Claude Code, or Pi agents via background process. Use when: (1) building/creating new fe → `/root/.claude/vault/library/coding-agent/SKILL.md`

Need something not listed? Run `vault-search <keywords>` (searches all vault skills + notes).


## pstack (poteto, Cursor/React core) — rigorous engineering skills
- Always-on: how, why (explain code/decisions), tdd, sharpen, correct (make repeated agent mistakes impossible), blast-radius (what a change can break, proven by running code), interrogate (adversarial multi-model review), benchmark-checklist, typescript-best-practices, technical-writing + unslop (no AI slop in prose), show-me-your-work (decision log for long runs), figure-it-out (auditable playbook for big changes), recall. Heavy, on request: /arena, /architect, /reflect, /teach. 24 principle-* skills + poteto-mode via `vault-search pstack <topic>`.

## Android development (official android/skills, Google)
- 30 skills for Android apps: Jetpack Compose (performance, styles, edge-to-edge, adaptive layouts, XML→Compose migration), Navigation 3 / navigation-event, CameraX, Media3 Cast, Glance & Wear OS widgets, Wear Compose M3, Android XR glasses (Glimmer), Android for Cars, Leanback→Compose TV, AGP 9 upgrade, R8 keep-rule analysis, android-profiler (Perfetto), testing-setup, Play Billing upgrade, Play policy insights, Engage SDK, Credential Manager (verified email, restore credentials), intent/permissions security, ML Kit GenAI (Gemini Nano), LiteRT, AppFunctions.
- Find with `vault-search android <topic>` (installed also in ~/.agents/skills). The `android` CLI (create/run/emulator/docs) is installed at /usr/local/bin/android.
