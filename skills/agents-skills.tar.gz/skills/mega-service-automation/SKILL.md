---
name: mega-service-automation
description: "Compose registered service workflows for reviewed n8n/Make workflows and scoped social/media automation. Use when these tasks need more than one relevant tool."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# mega-service-automation

Read `/root/.factory/service-tools/catalog.json` and load only the matching service skills: `service-n8n`, `service-make`, `service-oneup`, `service-publer`, `service-metricool`, `service-switchy`, `service-joturl`, `service-rafter`.

Define the requested outcome, existing artifacts, permitted target and budget. Prefer already available data and no-cost local/connected tools. Chain only the minimum necessary reads. Keep draft/research separate from sends, submissions, workflow runs, writes and uploads. Run scoped validation and report provider evidence without exposing credentials.

## Review before execution

1. Consult screened relevant `vault-mega-automation` references; a withheld note
   remains withheld. Clarify the intended instance, scenario/workflow, accounts,
   input/output data, timezone, schedule and budget.
2. Distinguish discovery/metadata from execution. n8n Public API keys are not its
   instance MCP access tokens. Only Webs-specific aliases and the fixed Webs host
   are eligible. Its initial MCP allowlist includes only `search_workflows`.
3. Make's toolbox URL/token are runtime-only and US2-scoped. Its initial local
   tool allowlist is empty. Inspect exact scenario effects before exposing a
   named tool; do not trust names or `readOnlyHint`. A test run can still publish,
   call a webhook, send a message, modify production or incur cost.
4. Do not retrieve complete workflow/code/credential exports just to check
   connectivity. Review data flow, inline-secret risks and external recipients
   before full workflow retrieval, editing, activation or execution.
5. For social steps use only the requested OneUp/Publer/Metricool account.
   Never turn an example using ALL accounts into a setup check. Keep drafts
   separate from scheduling/publishing; link creation/redirect changes are writes.
6. Apply Rafter at design, sensitive implementation, review and completion.
   Validate local workflow structure first. Obtain exact action authorization
   before external execution, even if a tool advertises read-only behavior.

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
