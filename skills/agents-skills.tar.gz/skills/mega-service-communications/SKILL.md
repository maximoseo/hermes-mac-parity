---
name: mega-service-communications
description: "Compose registered service workflows for email workflows, delivery diagnostics and project/task management. Use when these tasks need more than one relevant tool."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# mega-service-communications

Read `/root/.factory/service-tools/catalog.json` and load only the matching service skills: `service-resend`, `service-gmail`, `service-asana`. For relevant prompt design, also consider `service-prompt-architects`; do not share private messages or customer data with it without specific consent.

For social analytics/workflows, consider `service-metricool`. Verify token-plan
and brand scopes first. Keep analytics/drafts separate from publishing, scheduling,
inbox replies, ads and Drive/Canva account access; those need exact authorization.

For call-attribution context, use `service-callrail`: prefer aggregate analytics
over personal transcripts/recordings. Its call/SMS/write MCP tools are disabled.
For branded-link context, use `service-joturl` with existing read-only token
aliases. Do not shorten links, change redirects, reset tokens or create a session
merely to validate account access. A GET can still mutate data in JotURL.

For social scheduling use `service-oneup` or `service-publer` only as relevant.
OneUp uses OAuth; its old key-in-URL sample is not the preferred connection.
Publer uses Bearer-API and requires deliberate workspace/account selection before
posting. Switchy uses a workspace-scoped Api-Authorization header and a fixed
GraphQL workspace read. Never create a link or post for validation. Combine with
`mega-service-automation` only after reviewing the exact Make/n8n scenario.
Gmail remains managed OAuth, not an app-password fallback.

Define the requested outcome, existing artifacts, permitted target and budget. Prefer already available data and no-cost local/connected tools. Chain only the minimum necessary reads. Keep draft/research separate from sends, submissions, workflow runs, writes and uploads. Run scoped validation and report provider evidence without exposing credentials.

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
