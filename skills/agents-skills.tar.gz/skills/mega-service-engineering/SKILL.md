---
name: mega-service-engineering
description: "Compose CI/backend development with continuous Rafter secure design, incremental review, scoped tests and completion checks. Use Greptile, CodeRabbit, Qodo, Sourcery or TestSprite only when available and authorized."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# mega-service-engineering

Read `/root/.factory/service-tools/catalog.json` and load only the matching service skills: `service-circleci`, `service-insforge`, `service-rafter`, `service-greptile`, `service-coderabbit`, `service-qodo`, `service-sourcery`, `service-testsprite`.

Start with `/root/.factory/service-tools/RAFTER-WORKFLOW.md`: use
`rafter-secure-design` during planning, `rafter-code-review` during sensitive
implementation and diff review, then scoped tests and security checks at completion.
Revisit boundaries when architecture, permissions or dependencies change.
Check `blocked` and verification evidence before invoking any provider.
Qodo's public Open Aware is not private Context Engine access. TestSprite remains
blocked pending a reviewed vulnerability fix. No private code leaves this server
merely because a review/testing service is configured.

Consider `service-better-stack` for existing monitor context and `service-graphite`
for stack planning. (Bito and CodeAnt were removed from the review process and the
GitHub account on 2026-11-12 — do not plan review workflows around them.)
`service-e2b` is blocked on a deprecated/vulnerable MCP. `service-browserbase`
requires specific browser-job consent. `service-macroscope` describes a live
trigger webhook, not a safe discovery endpoint.

For utilities, consider `service-apyhub` only after region, selected tools, data
sharing and atom budget are clear. Its MCP OAuth key is not interchangeable with
the generic REST token. For CMS/UI work, use `service-builder-io`/`service-v0`
and `mega-service-design`; no CLI auth, source sync or deployment is automatic.

For automation use `service-n8n`/`service-make` and `mega-service-automation`.
Their REST and MCP credentials are separate. n8n initially exposes previews
only; Make initially exposes zero scenario calls pending effect review.
Full workflow reads can reveal inline secrets. Do not export credentials,
enable workflows, run tests/production or trigger webhooks for connectivity.

Define the requested outcome, existing artifacts, permitted target and budget. Prefer already available data and no-cost local/connected tools. Chain only the minimum necessary reads. Keep draft/research separate from sends, submissions, workflow runs, writes and uploads. Run scoped validation and report provider evidence without exposing credentials.

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
