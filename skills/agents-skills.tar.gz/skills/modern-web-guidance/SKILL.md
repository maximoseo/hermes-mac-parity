---
name: modern-web-guidance
description: "Use when writing or changing web UI code (HTML/CSS/clientside JS) — modals/dialogs/popovers, tables, dark mode, anchor positioning, container queries, view transitions, scroll animations, forms/validation, accessibility, scrollbars, Core Web Vitals, images, sanitization, web components, dates/timezones. Google Chrome team's modern web best-practices pack: query it BEFORE writing ad-hoc web UI solutions or adding polyfill dependencies. Not for backend/infra/tooling tasks."
---

# Modern Web Guidance — Chrome team's web best-practices pack (fleet install 2026-11-14, v1)

Verified: https://github.com/GoogleChrome/modern-web-guidance — 250 web features / 209 guides across CSS & layout, UX, performance, forms & UI, accessibility, built-in AI, security, PWA, WASM. Stewarded by the Google Chrome, Microsoft Edge, Mozilla Firefox and MDN teams. Code Apache-2.0, guide content CC-BY-4.0. Actively maintained (npm publish 2026-11-10).

Fleet install: checksum-verified npm artifact **`modern-web-guidance@1.0.0`** (sha512 `vafIZwC8AS6QjM2yyoflZbnc7n3/TVOMLbEMRdPTwcFy0f9/Tq8s5rJQ8UIqRt2KPl9ixravyaMR4nTGuUrcmg==`, upstream main at install `4dd96834`, skill-version `2026_11_09-5bcc021b`) extracted at **`/opt/fleet-tools/modern-web-guidance`** (Windows: `C:\fleet-tools\modern-web-guidance`). The npm package is the repo's published distribution and ships the CLI bin (the git tree does not commit it). One copy per host; wrapper `modern-web-guidance` on PATH (`/usr/local/bin/modern-web-guidance`) runs the pinned copy with `DISABLE_TELEMETRY=1` — guides retrieval is fully local, no network at query time.

## When to use

Any HTML/CSS/clientside-JS implementation work — dashboards-panel UI, sites, components, animations, forms, a11y fixes, performance work. Query it at the START of implementing/updating a web UI pattern, before writing ad-hoc solutions or adding polyfills/dependencies (training data is full of obsolete patterns; these guides are the current platform standard). Do NOT use for backend, infra/CI, or tooling tasks.

## How to query (search → retrieve → verify)

```bash
modern-web-guidance search "<2-5 word action-oriented query>"   # -> [{id, description}, ...]
modern-web-guidance retrieve "<id>"                             # full guide (large output is saved to a temp file — read it with your file tool)
modern-web-guidance legacy-scan <path> --json                   # ONLY for broad open-ended modernization audits of a whole codebase
```

- Query one UI/platform capability per search ("animate dialog modal backdrop", "responsive data table") — no framework/app names; split multi-feature tasks. If results are weak, rephrase once with the concrete UI noun (dialog, table, form) before giving up.
- Guides are vanilla HTML/CSS/JS — adapt to React/Next without dropping the modern feature (spread new HTML attrs as `any`, guard `window` in SSR, call `showModal()` on non-VDOM nodes, keep `:root`/`@starting-style` unscoped).
- Fallback policy: Baseline Widely available features need no fallback; for anything newer, follow the guide's fallback section unless the project declares its own browser-support policy.
- Offline fallback: the pinned copy's guides are readable markdown at `/opt/fleet-tools/modern-web-guidance/skills/modern-web-guidance/guides/<discipline>/<id>.md` (disciplines: css, html, js, forms, ui-components, ui-behaviors, ui-atoms, user-experience, visual-design, accessibility, performance, security, privacy, pwa, wasm, built-in-ai, webmcp).
- On Windows the wrapper is `modern-web-guidance.cmd` under `C:\fleet-tools\bin` (add to PATH); same CLI, same flags.

## Relationship to our own design contracts

This is a **general best-practices reference**, NOT the dashboards-panel design system. For dashboards-panel (and any dashboard UI) `src/styles/buttons.css` + the button audit harness stay authoritative (one primary per cluster, 48px phone / 36px desktop floors, RTL logical properties, ≥4.5:1 contrast, focus rings). Where a guide and a local contract overlap (dialogs, focus, contrast), satisfy BOTH — the local contract sets the floor, the guide supplies the modern platform pattern.

## Pitfalls

- Use the wrapper (`modern-web-guidance ...`), not `npx modern-web-guidance@latest` — the wrapper is the pinned 1.0.0 copy and works offline; `@latest` re-fetches unpinned from npm.
- The upstream SKILL.md says "MANDATORY: execute FIRST for all HTML/CSS tasks" and demands a `### Modern Web Guidance` disclosure section in every response — that's upstream's own convention for its skill; follow the search/retrieve workflow it describes but keep our own delivery/reporting conventions.
- `retrieve` output > 9.5 KB is written to a temp file (path printed) — read the file with your file tool, don't cat/head it.
- Do not run `legacy-scan` for single-feature tasks; it covers only the ~20% of guides with deterministic legacy rules.
- Telemetry is disabled via `DISABLE_TELEMETRY=1` in the wrapper (upstream would otherwise collect anonymous install counts, agent name, retrieval IDs and search queries).
- The pinned copy also ships a second skill `chrome-extensions` — we already have our own `chrome-extensions` skill; do not wire the upstream one without a rafter skill review.
- Requires Node >= 22 (fleet hosts run Node 24/26; win2 has Node via Program Files\nodejs).
