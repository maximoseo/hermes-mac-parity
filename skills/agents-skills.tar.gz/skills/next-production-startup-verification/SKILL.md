---
name: next-production-startup-verification
description: Verify a built Next.js application actually starts and serves its route contract after routing, framework or deployment changes. Use when a green build disagrees with startup or browser behavior.
metadata:
  version: "1.0.0"
  date: "2026-10-18"
---

# Verify the built Next.js server

Run the repository's production start command against its built artifact in an isolated environment. Use the CI Node/npm versions, a bounded readiness deadline, a task-owned port and guaranteed child-process cleanup. A passing build is not evidence that the production route tree starts.

When siblings beneath one route segment use different dynamic parameter names, such as `/repos/[id]` and `/repos/[owner]/[name]`, verify startup explicitly. Sharing the dynamic folder name and aliasing the parameter inside the nested handler can preserve both public URL contracts; do not infer a public URL rename from a filesystem parameter rename.

Check a known static response for startup, then representative dynamic routes and canonical links with authorized data. Assert response content and final URL, not just HTTP 200. Development mode, build success and a static readiness check do not replace real browser or deployed-artifact checks.

Keep deploy authorization, credentials and release gates unchanged. This procedure grants no production changes or synthetic login sessions.

Evidence: Radar audit implementation on 2026-10-18. Production build passed while the built server rejected sibling `id`/`owner` slugs. The shared-segment fix retained `/repos/obra/superpowers`, passed the new `scripts/startup-smoke.mjs` gate and real-data browser checks. Artifacts: `/root/work/radar-implementation-evidence-20261018/build.log` and `preview/{1440,768,390,320}.json`; PR `https://github.com/maximoseo/github-repos-radar/pull/91`. The evidence is isolated runtime verification, not a completed production release.
