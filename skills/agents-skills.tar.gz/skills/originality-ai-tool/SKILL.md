---
name: originality-ai-tool
description: Run AI content detection (lite, turbo, multilang), plagiarism checks, fact-checking, readability scoring, and grammar audits on text or URLs using the Originality.ai v3 MCP server and REST API.
---

# Originality.ai (`originality`) — AI Detection, Plagiarism, Fact-Check & Readability Skill

Use **Originality.ai** (`originality` MCP server and `https://api.originality.ai/api/v3`) automatically to audit generated or edited content for AI detection scores, plagiarism, factual accuracy, readability, and grammar before publishing or entregar to a client.

## Connection & Credentials (Always-On)
- **MCP Server**: `originality` (`/root/scripts/mcp-originality`, 4 tools)
- **REST API Base**: `https://api.originality.ai/api/v3` (`X-OAI-API-KEY` header)
- **Doppler (`agent-apis/prd` & `agents/prd`)**:
  - `ORIGINALITY_API_KEY` / `ORIGINALITY_AI_API_KEY`
  - Never hardcode or echo secret values.

## Available MCP Tools (`originality`)
| Tool | Endpoint | Description |
|------|----------|-------------|
| `check_balance` | `GET /api/v3/account/balance` | Check remaining `credits` and `subscriptionCredits` (free call). |
| `scan_content` | `POST /api/v3/scan` | Scan plain text for AI detection (`check_ai`), plagiarism (`check_plagiarism`), facts (`check_facts`), readability (`check_readability`), and grammar (`check_grammar`). |
| `scan_url` | `POST /api/v3/scan/url` | Scan a live public URL for AI detection, plagiarism, readability, and facts. |
| `get_scan` | `GET /api/v3/scan/:id` | Retrieve full details of a stored scan by ID. |

## Choosing the Right `aiModelVersion`
- `"lite"` (**Default for SEO & Editorial**): Tolerates light AI-assisted editing/proofreading while flagging raw unedited AI output.
- `"turbo"` (**Strict Mode**): Zero-tolerance AI detection; use when a client requires 100% human-written verification.
- `"multilang"` (**Non-English / Hebrew**): Use whenever scanning Hebrew, Spanish, French, German, or other non-English content.

## Automated Quality Gate Workflow
1. Draft or refine copy using `avoid-ai-writing` and `copy-editing` principles.
2. Run `originality` → `scan_content` (with `check_ai: true`, `check_readability: true`, and `aiModelVersion: "lite"` or `"multilang"` for Hebrew).
3. If the AI score is high, rewrite the flagged sentences with concrete human specifics, varied cadence, and direct voice, then re-scan until clean.

<!-- content-services-routing:start -->

## Connected content services

For downstream media rendering, social distribution/analytics, or originality checks, route to [content-ops-mega](/root/.agents/skills/content-ops-mega/SKILL.md). It selects HTML/CSS to Image, Creatomate, Metricool, Postiz, AdaptlyPost, Copyscape, or Originality.ai according to the deliverable. Preserve this skill's existing generation/research workflow; invoke only the additional capability the task needs. The canonical service skill and live schema take precedence over historical tool names/counts in this document. Model-backed tools require verified subscription coverage; service credentials alone do not establish it.

<!-- content-services-routing:end -->
