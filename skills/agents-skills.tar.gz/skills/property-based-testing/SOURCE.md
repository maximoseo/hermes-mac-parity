# Source
- Repo: https://github.com/trailofbits/skills (path trailofbits_skills/plugins/property-based-testing/skills/property-based-testing)
- Commit: 149d7b21f4067765b82e67029730b42d228ef4b4 (pinned)
- License: CC-BY-SA-4.0
- Installed: 2026-11-16 by Claude Code @Claude64Srv35Bot (srv735) at owner request
- Review: rafter skill review + independent per-repo read (workflow wf_943ab8ec-c10); details in /root/work/skills-quarantine-20261116/_review.json
