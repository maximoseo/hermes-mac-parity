---
name: review-ui-with-kombai
description: Get a UI/UX review from Kombai — visual hierarchy, spacing, color, consistency, usability. Use when the user asks Kombai to review or critique existing UI without changing it.
---

Send the request with the Kombai MCP server's `chat_start` tool: `mode: "chat"` (Q&A — nothing is modified), an absolute `workspace_root`, and a `prompt` asking for a UI/UX review that names the pages, components or flows to examine. Attach the relevant files and screenshots via `attachments`.

Poll `chat_status({ run_id, wait: 30 })` until `keep_polling` is false, read `transcript_file_path`, and relay the findings to the user grouped by severity if the review didn't already. If status is `awaiting_user_input`, ask Kombai's `question` in this chat and send the reply with `chat_answer` (with no `question`, tell the user where to answer it, per the rules above), then keep polling; the next reply comes as soon as they answer.

If the run errors or stalls, or the user says something went wrong with Kombai, use `kombai-status` to check the app, account and connection before retrying.
