---
name: semrush-backlink-audit
description: Audit backlink profiles with the semrush CLI. Use when the user asks for backlink analysis, referring domains, authority score, anchor text, indexed linked pages, backlink competitors, link gaps, backlink history, toxic or suspicious link signals, or off-page SEO recommendations based on Semrush CLI backlink data.
---

# Semrush Backlink Audit

Use `semrush backlink ...` commands to evaluate authority, link profile health, anchor distribution, competitor gaps, and link-building priorities.

## Prerequisites

Check install and auth when needed:

```bash
command -v semrush
semrush account auth status --output json --quiet
```

Choose the right `--target-type` before running reports:

| Target type | Use |
|---|---|
| `root_domain` | Whole domain, default for audits and competitor comparisons. |
| `domain` | Host/subdomain-level analysis. |
| `url` | Specific page-level analysis. |

## Workflow

1. Confirm target, target type, competitors, and audit purpose.
2. Pull overview, authority score, referring domains, anchors, and indexed pages.
3. Compare against competitors for link gaps and authority benchmarks.
4. Inspect link list, filters, TLD, geo, categories, and history when needed.
5. Separate findings into risks, opportunities, and validation follow-ups.

## Core Commands

Profile baseline:

```bash
semrush backlink overview example.com --target-type root_domain --output json --quiet
semrush backlink authority-score example.com --target-type root_domain --output json --quiet
semrush backlink history example.com --target-type root_domain --output json --quiet
```

Profile composition:

```bash
semrush backlink referring-domains example.com --target-type root_domain --limit 100 --output json --quiet
semrush backlink anchors example.com --target-type root_domain --limit 100 --output json --quiet
semrush backlink indexed-pages example.com --target-type root_domain --limit 100 --output json --quiet
semrush backlink tld-distribution example.com --target-type root_domain --output json --quiet
semrush backlink geo example.com --target-type root_domain --output json --quiet
semrush backlink categories example.com --target-type root_domain --output json --quiet
semrush backlink category-profile example.com --target-type root_domain --output json --quiet
```

Individual links and comparisons:

```bash
semrush backlink list example.com --target-type root_domain --limit 250 --output json --quiet
semrush backlink list example.com --target-type root_domain --filter "type=text" --sort "page_ascore desc" --limit 250 --output json --quiet
semrush backlink competitors example.com --target-type root_domain --limit 50 --output json --quiet
semrush backlink compare example.com competitor.com --target-type root_domain --output json --quiet
semrush backlink batch example.com competitor.com another.com --target-type root_domain --output json --quiet
```

## Interpretation

Use these checks before recommending action:

| Check | Look for |
|---|---|
| Referring domain quality | Authority, topical fit, country/TLD mix, and link concentration. |
| Anchor distribution | Excess exact-match anchors, irrelevant anchors, or missing branded anchors. |
| Indexed linked pages | Pages attracting links and pages that need consolidation or redirects. |
| Link velocity | Sudden spikes or drops that need manual validation. |
| Competitor gap | High-quality domains linking to competitors but not the target. |

Do not label links as toxic from Semrush data alone. Flag suspicious patterns and recommend manual review before disavow decisions.

## Output Format

Return:

1. Profile snapshot: authority, backlinks, referring domains, target type, and database/command context.
2. Health findings: risks with evidence and confidence.
3. Opportunity findings: linkable assets, competitor gaps, and outreach targets.
4. Action list: preserve, reclaim, build, monitor, or manually review.
5. Commands run and any filters used.

## Related Skills

- Use `semrush-competitor-research` to connect link gaps to keyword gaps.
- Use `semrush-traffic-trends` to verify whether authority changes align with traffic movement.
- Use `semrush-batch-workflows` for repeated backlink overview and list recipes.
