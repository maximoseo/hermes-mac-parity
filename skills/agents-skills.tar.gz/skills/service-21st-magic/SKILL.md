---
name: service-21st-magic
description: "Use 21st.dev / Magic for Find UI components and perform explicitly authorized UI generation. Triggers: 21st magic components component ui inspiration \u05e7\u05d5\u05de\u05e4\u05d5\u05e0\u05e0\u05d8\u05d5\u05ea \u05e2\u05d9\u05e6\u05d5\u05d1. Resolve authentication safely and act only within the user's request."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# service-21st-magic

Find UI components and perform explicitly authorized UI generation.

Source of truth: `/root/.factory/service-tools/catalog.json` → `21st-magic`.

## Workflow

1. Match the task and read the service entry. Official Magic 0.2.3 documentation says it is now a compatibility proxy for the unified 21st MCP. All old Magic API keys were reset; obtain a fresh key securely if discovery fails. Use the fixed hosted endpoint without a latest installer or key in argv. Paid code retrieval/generation and profile/library mutations require exact task and cost authorization.
2. Use connected native tools if available. Otherwise use the reviewed MCP/CLI/REST route described in that entry; do not invent tools/endpoints.
3. A reviewed free check, when defined, is `python3 /root/.factory/service-tools/service_tools.py probe 21st-magic`. It returns status only, not private account contents.
4. Supported REST operations are listed in the catalog. Use `python3 /root/.factory/service-tools/service_tools.py call 21st-magic OPERATION` with a JSON payload on stdin. The wrapper rejects credential fields and redirects. `--approved-action` is only appropriate after the user has authorized that exact paid or outward-facing action.
5. Inspect the result and report actual status, completeness, cost/scope limitations and any next authorization step.

## 21st CLI (pinned, fleet-wide 2026-11-09)

Preferred route for component discovery/install and for UI generation once the task authorizes it:

- Install: `npm i -g @21st-dev/cli@1.18.0` (pinned exact version; deployed on all fleet servers — srv735, srv745, srv877, srv935, srv739, srv806, srv186, srv106; srv1982221 never).
- Auth (non-interactive): the token is Doppler `MAGIC_21ST_API_KEY` (project `agent-apis`, config `prd`) — reference by NAME only, never hardcode or print it. Use the fleet wrapper `/usr/local/bin/21st-run <cmd>`: it resolves the token into `TWENTYFIRST_TOKEN` in memory and execs `21st`. Equivalent manual invocation: `TWENTYFIRST_TOKEN="$(doppler secrets get MAGIC_21ST_API_KEY --project agent-apis --config prd --plain)" 21st ...`.
- Key commands: `21st-run search "<query>" [--type c|theme|template] [--limit N] [--json]` (find components/themes/templates), `21st-run get <id>` (component code + demo), `21st-run add <user>/<slug>` (install a published component into a project), `21st-run generate "<prompt>"` (AI sketch variants — consumes AI credits, needs explicit user authorization), `21st-run usage` (quota). Free without login: `21st logo <query>` (SVG logos).
- Smoke: `21st-run search "button" --limit 2 --json` must return results — this is the auth proof. Note: `21st whoami` reflects only a browser-login file, so "Not logged in" there does NOT mean the env token failed.
- Never run `21st login` on a headless server (it blocks waiting for a browser callback).
- Paid code retrieval/generation and profile/library mutations still require exact task + cost authorization per the operating boundaries below.

## References

- https://21st.dev/mcp
- https://github.com/21st-dev/magic-mcp

## Runtime-authenticated MCP

The personal MCP entry launches `python3 /root/.factory/service-tools/service_tools.py mcp 21st-magic`. This resolves only this provider's credential in memory and uses a fixed endpoint/script with a minimal child environment. Discovery does not authorize paid jobs, private context uploads or mutations. Use discovered tools rather than bypassing a connected MCP with REST.

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
