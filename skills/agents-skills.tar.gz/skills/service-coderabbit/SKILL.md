---
name: service-coderabbit
description: "Use CodeRabbit for Use existing code-review context and organization/repository review data. Triggers: coderabbit rabbit reviewer review \u05e7\u05d5\u05d3\u05e8\u05d1\u05d9\u05d8. Resolve authentication safely and act only within the user's request."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# service-coderabbit

Use existing code-review context and organization/repository review data.

Source of truth: `/root/.factory/service-tools/catalog.json` → `coderabbit`.

## Workflow

1. Match the task and read the service entry. The rendered official Swagger documents `x-coderabbitai-api-key`, not Bearer. Only no-cost `/v1/organizations` is enabled in the REST wrapper. User/organization and agentic/CLI keys have different scopes; do not substitute an agentic key automatically. Source uploads, remote reviews, seats/roles changes and PR comments require specific authorization.
2. Use connected native tools if available. Otherwise use the reviewed MCP/CLI/REST route described in that entry; do not invent tools/endpoints.
3. A reviewed free check, when defined, is `python3 /root/.factory/service-tools/service_tools.py probe coderabbit`. It returns status only, not private account contents.
4. Supported REST operations are listed in the catalog. Use `python3 /root/.factory/service-tools/service_tools.py call coderabbit OPERATION` with a JSON payload on stdin. The wrapper rejects credential fields and redirects. `--approved-action` is only appropriate after the user has authorized that exact paid or outward-facing action.
5. Inspect the result and report actual status, completeness, cost/scope limitations and any next authorization step.

## References

- https://api.coderabbit.ai/v1/docs/
- https://docs.coderabbit.ai/api

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
