---
name: service-kie
description: "Use KIE for Inspect Webs media-generation capacity and plan budgeted AI media work. Triggers: kie kie.ai video-generation image-generation music-generation \u05e7\u05d9. Resolve authentication safely and act only within the user's request."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# service-kie

Inspect Webs media-generation capacity and plan budgeted AI media work.

Source of truth: `/root/.factory/service-tools/catalog.json` → `kie`.

## Workflow

1. Match the task and read the service entry. Prefer the new Webs key; no generic/private-account fallback or alternate-key retry after rejection. Normalize an optional stored Bearer prefix once. HTTP 200 may contain provider code 401: require code 200 and numeric data. Credit reads are not media generation or permission for uploads, signed download links, callbacks/webhooks or billed model jobs.
2. Use connected native tools if available. Otherwise use the reviewed MCP/CLI/REST route described in that entry; do not invent tools/endpoints.
3. A reviewed free check, when defined, is `python3 /root/.factory/service-tools/service_tools.py probe kie`. It returns status only, not private account contents.
4. Supported REST operations are listed in the catalog. Use `python3 /root/.factory/service-tools/service_tools.py call kie OPERATION` with a JSON payload on stdin. The wrapper rejects credential fields and redirects. `--approved-action` is only appropriate after the user has authorized that exact paid or outward-facing action.
5. Inspect the result and report actual status, completeness, cost/scope limitations and any next authorization step.

## References

- https://docs.kie.ai/common-api/get-account-credits

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
