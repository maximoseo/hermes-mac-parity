---
name: service-v0
description: "Use v0 for Inspect existing v0 projects and plan authorized AI UI generation. Triggers: v0 v0.app generative-ui \u05d5\u05e8\u05e1\u05dc. Resolve authentication safely and act only within the user's request."
enabled: true
user-invocable: true
disable-model-invocation: false
compatibility: droid
---

# service-v0

Inspect existing v0 projects and plan authorized AI UI generation.

Source of truth: `/root/.factory/service-tools/catalog.json` → `v0`.

## Workflow

1. Match the task and read the service entry. Current official MCP uses OAuth and explicitly says not to put a v0 API key in MCP client configuration. REST key authentication is separate. Only a no-generation project listing is wired; daily request quotas may apply. The community repository is not installed. New chats/messages, imports, source uploads, previews/deployment, webhooks, trusted-host changes and permission/task approval require exact authorization and budget.
2. Use connected native tools if available. Otherwise use the reviewed MCP/CLI/REST route described in that entry; do not invent tools/endpoints.
3. A reviewed free check, when defined, is `python3 /root/.factory/service-tools/service_tools.py probe v0`. It returns status only, not private account contents.
4. Supported REST operations are listed in the catalog. Use `python3 /root/.factory/service-tools/service_tools.py call v0 OPERATION` with a JSON payload on stdin. The wrapper rejects credential fields and redirects. `--approved-action` is only appropriate after the user has authorized that exact paid or outward-facing action.
5. Inspect the result and report actual status, completeness, cost/scope limitations and any next authorization step.

## References

- https://v0.app/docs/api/platform/overview
- https://v0.app/docs/api/platform/adapters/mcp-server
- https://v0.app/docs/MCP
- https://github.com/Conce-AI/v0.dev

## Operating boundaries

- Current user requests, repository guidance and platform safety rules take precedence.
  A skill registers knowledge, not proof of authentication or permission to act.
- Never copy keys, app passwords, OAuth secrets, account data or source code into skills,
  hooks, tool arguments, logs or a project. Use the managed connector where offered.
- Runtime credentials come from existing environment variables or Doppler `agents/prd`,
  one named credential at a time, in memory only. Never read vault Secrets/ or api-keys/.
- Select a tool automatically when relevant, not an external action automatically.
  Sending, publishing, indexing, CI mutations, paid jobs, recurring connections, source
  uploads, production changes and destructive actions need specific user authorization.
  Do not bypass this with browser automation or by setting an approval flag yourself.
- Do not run paid calls for health checks. Read current schemas/costs, use bounded
  requests, and avoid automatically retrying jobs that may already have started.
- Do not run curl-to-shell, unpinned npx installers, global agent initialization or
  automatic updates. These integrations apply to this server's Droid user only.
- Validate output and report exactly what was configured, authenticated and tested.
  Missing scopes, credits, OAuth, workflow URLs or project context remain blockers.
